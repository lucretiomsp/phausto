# Description

Modeled after D. Bartocha and . Baron, Influence of Tin Bronze Melting and Pouring Parameters on Its Properties and Bell' Tone, Archives of Foundry Engineering, 2016.

Model height is 2 meters.

To turn `russianBell.obj` into a Faust physical model (`russianBellModel.lib`), just run `./build`.
