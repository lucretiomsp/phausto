# Faust Libraries

This folder contains tools to analyse the libraries. For the time being, it computes only the dependencies between the libraries.

### Usage:
~~~~~~~~~~~~~
make
~~~~~~~~~~~~~
on output, you should find a pdf file containing a graph of the dependencies.

or 
~~~~~~~~~~~~~
make help
~~~~~~~~~~~~~

### Note

You must have `dot` installed to run `make`
