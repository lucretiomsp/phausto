# DX7 Preset File Libraries

This folder contains DX7 preset libraries generated using `dx72faust`
(see `tools/dx72faust`) from Yamaha DX7 preset files (`.syx`). To re-generate
all the libraries from the `.syx` files contained in this folder, just run:

```
makelibs
```
