#include <stdio.h>
#include <dlfcn.h>

// Define a function pointer type for getLastError()
typedef const char* (*getLastErrorFunc)();

int main() {
    // Load the libfaust library
    void* libfaust_handle = dlopen("./libfaust.2.dylib", RTLD_LAZY);
    if (!libfaust_handle) {
        fprintf(stderr, "Error: Unable to load libfaust library: %s\n", dlerror());
        return 1;
    }

    // Load the getLastError function from the libfaust library
    getLastErrorFunc getFaustError = (getLastErrorFunc)dlsym(libfaust_handle, "getLastError");
    const char* faust_error_message = NULL;

    if ((faust_error_message = dlerror()) != NULL) {
        fprintf(stderr, "Error: Unable to find symbol in libfaust: %s\n", faust_error_message);
        dlclose(libfaust_handle);
        return 1;
    }

    // Call the getLastError function from the libfaust library
    const char* faust_last_error = getFaustError();
    printf("LibFaust Last error: %s\n", faust_last_error);

    // Close the libfaust library
    dlclose(libfaust_handle);

    // Load the libportaudio library
    void* libportaudio_handle = dlopen("./libportaudio.dylib", RTLD_LAZY);
    if (!libportaudio_handle) {
        fprintf(stderr, "Error: Unable to load libportaudio library: %s\n", dlerror());
        return 1;
    }

    // Load the getLastError function from the libportaudio library
    getLastErrorFunc getPortaudioError = (getLastErrorFunc)dlsym(libportaudio_handle, "getLastError");
    const char* portaudio_error_message = NULL;

    if ((portaudio_error_message = dlerror()) != NULL) {
        fprintf(stderr, "Error: Unable to find symbol in libportaudio: %s\n", portaudio_error_message);
        dlclose(libportaudio_handle);
        return 1;
    }

    // Call the getLastError function from the libportaudio library
    const char* portaudio_last_error = getPortaudioError();
    printf("LibPortaudio Last error: %s\n", portaudio_last_error);

    // Close the libportaudio library
    dlclose(libportaudio_handle);

    return 0;
}
